# Internal adversarial review (CMAME-style referee report)

*Written as a separate critical pass on the revised draft. A genuinely independent
sub-agent was not available in this environment; treat this as a self-review written
to be as hostile as a real referee. Items marked FIXED were addressed in the text.*

## Summary of the submission
The paper shows that second-derivative Haar wavelet collocation is midpoint quadratic
spline collocation, derives a three-term identity for arbitrary knots, proves symmetry
and DCT/DST diagonalization on uniform grids, gives a fourth-order spectral correction,
proves energy stability and mass conservation of SAV-BDF2 schemes for Allen--Cahn and
Cahn--Hilliard, and demonstrates automatic anisotropic refinement for an elastic corner
singularity with fast-diagonalization-preconditioned GMRES.

## Overall assessment
The work is correct as far as I can check, and it is unusually reproducible: all tables
are generated from code. The numerical evidence matches the theory closely. The main
problem is **positioning**. Much of the one-dimensional theory is known in the
quadratic-spline-collocation (QSC) literature, and on uniform boxes the phase-field
scheme competes with compact finite differences and cosine pseudo-spectral methods,
which the paper does not compare against. In its current form I would recommend
**major revision** at CMAME. The paper would be competitive at a numerical-analysis
leaning venue (J. Sci. Comput., CAMWA, Appl. Numer. Math.) once the points below are
addressed.

## Major comments
1. **Novelty versus QSC.** The uniform interior relation, the symmetric form of the
   uniform operator, its trigonometric eigenvectors with FFT solvers, and "optimal"
   fourth-order QSC perturbations are known (Houstis et al. 1988; Christara 1994;
   Christara and Ng 2002, 2006). Christara and Ng (2006) treat non-uniform partitions,
   so the non-uniform identity may also be known in some form. The claims must be
   stated precisely. *FIXED in part: claims softened, Christara & Ng (2006) cited.
   Author action: read that paper and state exactly what is new in Theorem 1.*
2. **Why not compact FD or spectral methods on uniform boxes?** On a uniform grid with
   Neumann conditions, D2^(4) is a fourth-order compact-type difference operator, and a
   cosine pseudo-spectral method has spectral accuracy at the same O(N^d log N) cost.
   The phase-field section must either compare against these (accuracy per DOF and per
   second) or argue clearly why the HWCM formulation matters, for instance through
   seamless graded grids or a unified framework. *FIXED in part: a remark was added.
   A comparison is still needed.*
3. **Elasticity benchmark.** *Largely ADDRESSED in revision 2.* Traction boundary
   conditions are now implemented: collocation at edge midpoints, a corner rule for two
   traction edges, and a Neumann-closure preconditioner. They are second order for every
   tested configuration, with 18-27 GMRES iterations. A new singular test places the
   apex at the tip of a traction-free face, which is the local structure of the L-shaped
   re-entrant corner; the adaptive rate is DOF^-1.00. Still missing: the full L-shaped
   domain, which needs multi-patch coupling. New weakness exposed: with traction edges
   the iteration counts degrade faster as nu -> 1/2 (about 400 at nu = 0.499), because the
   preconditioner decouples u and v in the traction rows.
4. **No comparison with established adaptive methods.** CMAME readers expect a
   comparison with adaptive FEM (for example Q2 with a residual estimator) or adaptive
   hierarchical IGA collocation (Schillinger et al. 2013) on error versus DOFs and
   versus wall time.
5. **The indicator is heuristic.** Eq. (indicator) has no reliability or efficiency
   proof. The observed effectivity is good (Fig. 1a), but the claim should be phrased
   as empirical. *FIXED (wording).*
6. **GPU claims without GPU data.** The title, abstract and Section 3 advertise a GPU
   implementation, but Table 10 has no GPU column. Either provide the numbers or remove
   GPU from the abstract. *FIXED provisionally: abstract wording now says
   "designed for"; the numbers must be added before submission.*
7. **Near-incompressibility.** Errors grow by about 80x and iterations by about 9x as
   nu goes from 0.3 to 0.499. Acknowledged, but this weakens the elasticity
   contribution.

## Minor comments
- Real spectrum of D2 on graded grids is observed, not proven; the energy theory is
  uniform-grid only. (Acknowledged in Sec. 7.)
- The 3D spinodal run has zero mean, so the absolute mass deviation of 1e-19 is less
  informative. Report the relative deviation, or use a nonzero mean.
- The SAV restart in the 2D spinodal run is a modelling choice and should be mentioned
  in the theorem's scope (energy is guaranteed per segment). (Mentioned.)
- The Allen--Cahn table mixes model error with discretization error; the text now
  separates them. *FIXED.*
- Verify every bibliographic entry, page and volume numbers in particular.
- Please report the wall time of the one-time eigendecomposition. (Partially:
  mentioned as amortized.)

## Recommendation
Major revision. To reach CMAME level, add: (i) an L-shaped multi-patch elasticity
example with traction-free faces; (ii) comparisons with adaptive FEM or IGA collocation
and, for phase-field, with compact FD or pseudo-spectral methods; (iii) GPU results.
Without (i) and (ii), target J. Sci. Comput. or CAMWA.
