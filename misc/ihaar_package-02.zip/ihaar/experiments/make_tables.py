"""Generate LaTeX tables from results/*.json (no hand-copied numbers)."""
import json, os, numpy as np
R = lambda n: json.load(open(os.path.join("results", n + ".json")))
T = "paper/tables"
e = lambda v: "--" if v is None else ("%.2e" % v).replace("e-0", "e-").replace("e+0", "e+")
def sci(v):
    if v is None: return "--"
    m, x = ("%.2e" % v).split("e"); return f"${m}\\times10^{{{int(x)}}}$"
def rate(a, b, na, nb): return "--" if a is None else "%.2f" % (np.log(a / b) / np.log(nb / na))
def w(name, s): open(os.path.join(T, name + ".tex"), "w").write(s)

E1 = R("E1")
s = "\\begin{tabular}{r cc cc cc}\n\\toprule\n & \\multicolumn{2}{c}{Dirichlet, uniform} & \\multicolumn{2}{c}{Dirichlet, Chebyshev-graded} & \\multicolumn{2}{c}{}\\\\\n$N$ & error & rate & error & rate \\\\\n\\midrule\n"
s = "\\begin{tabular}{r cc cc | cc cc}\n\\toprule\n & \\multicolumn{4}{c|}{Dirichlet, $-\\Delta u=f$ (2nd-order operator)} & \\multicolumn{4}{c}{Neumann, $(I-\\Delta)u=f$}\\\\\n & \\multicolumn{2}{c}{uniform} & \\multicolumn{2}{c|}{graded} & \\multicolumn{2}{c}{$D_2$ (Eq.~\\eqref{eq:D2})} & \\multicolumn{2}{c}{$D_2^{(4)}$ (Eq.~\\eqref{eq:D24})}\\\\\n$N$ & error & rate & error & rate & error & rate & error & rate\\\\\n\\midrule\n"
d, n = E1["dirichlet"], E1["neumann"]
for i in range(len(d)):
    r = lambda L, key: "--" if i == 0 else rate(L[i-1][key], L[i][key], L[i-1]["N"], L[i]["N"])
    s += f"{d[i]['N']} & {sci(d[i]['uniform'])} & {r(d,'uniform')} & {sci(d[i]['graded'])} & {r(d,'graded')} & {sci(n[i]['order2'])} & {r(n,'order2')} & {sci(n[i]['order4'])} & {r(n,'order4')}\\\\\n"
w("t_poisson", s + "\\bottomrule\n\\end{tabular}\n")

s = "\\begin{tabular}{rr cccc}\n\\toprule\n$N$ & DOFs & dense (classical) & Bartels--Stewart & FDM (GEMM) & FDM (DCT)\\\\\n\\midrule\n"
for r in E1["cost"]:
    f = lambda k: "--" if k not in r else "%.2e" % r[k]
    s += f"{r['N']} & {r['dofs']} & {f('dense')} & {f('bartels_stewart')} & {f('fdm_gemm')} & {f('dct')}\\\\\n"
w("t_cost", s + "\\bottomrule\n\\end{tabular}\n")

E2 = R("E2")
s = "\\begin{tabular}{rr cc cr}\n\\toprule\n$N$ & DOFs & $e_{H^1}$ & rate (in $N$) & $e_\\infty$ & GMRES its\\\\\n\\midrule\n"
L = E2["smooth"]
for i, r in enumerate(L):
    s += f"{r['N']} & {r['dofs']} & {sci(r['eH1'])} & {'--' if i==0 else rate(L[i-1]['eH1'], r['eH1'], L[i-1]['N'], r['N'])} & {sci(r['einf'])} & {r['its']}\\\\\n"
w("t_el_smooth", s + "\\bottomrule\n\\end{tabular}\n")
s = "\\begin{tabular}{l ccc ccc}\n\\toprule\n & \\multicolumn{3}{c}{GMRES iterations} & \\multicolumn{3}{c}{$e_{H^1}$}\\\\\n$\\nu$ & $N=32$ & $64$ & $128$ & $N=32$ & $64$ & $128$\\\\\n\\midrule\n"
for r in E2["nu"]:
    s += f"{r['nu']} & {r['its32']} & {r['its64']} & {r['its128']} & {sci(r['e32'])} & {sci(r['e64'])} & {sci(r['e128'])}\\\\\n"
w("t_el_nu", s + "\\bottomrule\n\\end{tabular}\n")
s = "\\begin{tabular}{rrc rrcccr}\n\\toprule\n\\multicolumn{3}{c}{uniform} & \\multicolumn{6}{c}{automatic (Haar-detail indicator)}\\\\\n\\cmidrule(lr){1-3}\\cmidrule(lr){4-9}\nDOFs & $e_{H^1}$ & its & cycle & DOFs & $e_{H^1}$ & $h_{\\min}$ & $\\kappa(V)$ & its\\\\\n\\midrule\n"
U = E2["sing_uniform"]; A = E2["sing_adaptive"]; sel = [A[k] for k in range(0, len(A), max(1, len(A)//8))] + ([A[-1]] if (len(A)-1) % max(1, len(A)//8) else [])
for i in range(max(len(U), len(sel))):
    u = U[i] if i < len(U) else None; a = sel[i] if i < len(sel) else None
    s += (f"{u['dofs']} & {sci(u['eH1'])} & {u['its']}" if u else "& &") + " & " + \
         (f"{a['cycle']} & {a['dofs']} & {sci(a['eH1'])} & {sci(a['hmin'])} & {a['condV']:.1f} & {a['its']}" if a else "& & & & &") + "\\\\\n"
w("t_el_sing", s + "\\bottomrule\n\\end{tabular}\n")

E3 = R("E3")
s = "\\begin{tabular}{l cccc}\n\\toprule\nrun & fitted $\\mathrm{d}R^2/\\mathrm{d}t$ & rel.\\ deviation from $-2\\varepsilon^2$ & $\\max_n(\\tilde E^{n+1}-\\tilde E^n)$ & $\\max_n(E_h^{n+1}-E_h^n)$\\\\\n\\midrule\n"
for k, v in E3["runs"].items():
    N, o = k[1:].split("_o")
    s += f"$N={N}$, order {o} & {sci(v['slope'])} & {abs(v['slope']/(-2*E3['eps']**2)-1)*100:.2f}\\% & {sci(v['max_dEmod'])} & {sci(v['max_dE'])}\\\\\n"
w("t_ac", s + "\\bottomrule\n\\end{tabular}\n")

E4 = R("E4"); sp = E4["spatial"]
s = "\\begin{tabular}{r cc cc}\n\\toprule\n & \\multicolumn{2}{c}{$D_2$} & \\multicolumn{2}{c}{$D_2^{(4)}$}\\\\\n$N$ & error & rate & error & rate\\\\\n\\midrule\n"
for i, N in enumerate(sp["N"]):
    r2 = "--" if i == 0 else rate(sp["order2"][i-1], sp["order2"][i], sp["N"][i-1], N)
    r4 = "--" if i == 0 else rate(sp["order4"][i-1], sp["order4"][i], sp["N"][i-1], N)
    s += f"{N} & {sci(sp['order2'][i])} & {r2} & {sci(sp['order4'][i])} & {r4}\\\\\n"
w("t_ch_space", s + "\\bottomrule\n\\end{tabular}\n")
tp = E4["temporal"]
s = "\\begin{tabular}{c cc}\n\\toprule\n$\\Delta t$ & error & rate\\\\\n\\midrule\n"
for i, dt in enumerate(tp["dt"]):
    s += f"{sci(dt)} & {sci(tp['err'][i])} & {'--' if i==0 else rate(tp['err'][i-1], tp['err'][i], 1/tp['dt'][i-1], 1/dt)}\\\\\n"
w("t_ch_time", s + "\\bottomrule\n\\end{tabular}\n")

E5 = R("E5"); spd = E4["spinodal"]
s = "\\begin{tabular}{l cc}\n\\toprule\n & 2D spinodal & 3D spinodal\\\\\n\\midrule\n"
s += f"grid & ${spd['N']}^2$ & ${E5['N']}^3$\\\\\n$\\varepsilon$ & {spd['eps']} & {E5['eps']}\\\\\n"
s += f"steps & {spd['steps']}+4500 & {E5['steps']}\\\\\n"
s += f"$\\max_n|M_h^n-M_h^0|$ & {sci(spd['max_mass_dev'])} & {sci(E5['mass_dev'])}\\\\\n"
s += f"$\\max_n(\\tilde E^{{n+1}}-\\tilde E^n)$ & {sci(spd['max_dEmod'])} & {sci(E5['max_dEmod'])}\\\\\n"
s += f"$\\max_n(E_h^{{n+1}}-E_h^n)$ (sampled) & {sci(spd['max_dE'])} & {sci(E5['max_dE'])}\\\\\n"
s += f"$\\xi=r/\\sqrt{{E_1+C}}$ range & [{spd['xi_min']:.6f}, {spd['xi_max']:.6f}] & --\\\\\n"
s += f"CPU time/step (1 core) & {spd['time_per_step']*1e3:.1f} ms & {E5['time_per_step']*1e3:.0f} ms\\\\\n"
w("t_spinodal", s + "\\bottomrule\n\\end{tabular}\n")

E6 = R("E6_cpu"); gpu = R("E6_gpu") if os.path.exists("results/E6_gpu.json") else None
s = "\\begin{tabular}{rr r cc cc}\n\\toprule\n & & & \\multicolumn{2}{c}{CPU, 1 core, float64 (ms/step)} & \\multicolumn{2}{c}{GPU (ms/step)}\\\\\n$d$ & $N$ & DOFs & GEMM & DCT & GEMM & DCT\\\\\n\\midrule\n"
keys = sorted({(r["dim"], r["N"]) for r in E6})
for dim, N in keys:
    c = {r["transform"]: r["ms_per_step"] for r in E6 if r["dim"] == dim and r["N"] == N}
    g = {r["transform"]: r["ms_per_step"] for r in gpu if r["dim"] == dim and r["N"] == N and r["dtype"] == "float64"} if gpu else {}
    f = lambda D, k: "%.2f" % D[k] if k in D else ("\\textit{pending}" if D is g else "--")
    s += f"{dim} & {N} & {N**dim} & {f(c,'gemm')} & {f(c,'dct')} & {f(g,'gemm')} & {f(g,'dct')}\\\\\n"
w("t_perf", s + "\\bottomrule\n\\end{tabular}\n")
print("tables written")

# ---------------- E7: traction boundary conditions ----------------------
if os.path.exists("results/E7.json"):
    E7 = R("E7")
    sm = E7["smooth"]; names = list(sm.keys())
    s = "\\begin{tabular}{r " + "cc " * len(names) + "}\n\\toprule\n & " + " & ".join(
        f"\\multicolumn{{2}}{{c}}{{traction on {n}}}" for n in names) + "\\\\\n$N$ & " + " & ".join(["error & rate"] * len(names)) + "\\\\\n\\midrule\n"
    for i in range(len(sm[names[0]])):
        cells = []
        for n in names:
            L = sm[n]; cells.append(sci(L[i]["eH1"])); cells.append("--" if i == 0 else rate(L[i-1]["eH1"], L[i]["eH1"], L[i-1]["N"], L[i]["N"]))
        s += f"{sm[names[0]][i]['N']} & " + " & ".join(cells) + "\\\\\n"
    s += "\\midrule\nGMRES its & " + " & ".join(f"\\multicolumn{{2}}{{c}}{{{min(r['its'] for r in sm[n])}--{max(r['its'] for r in sm[n])}}}" for n in names) + "\\\\\n"
    s += "edge error ($N{=}256$) & " + " & ".join(f"\\multicolumn{{2}}{{c}}{{{sci(sm[n][-1]['eedge'])}}}" for n in names) + "\\\\\n"
    w("t_trac_smooth", s + "\\bottomrule\n\\end{tabular}\n")
    s = "\\begin{tabular}{l ccc ccc}\n\\toprule\n & \\multicolumn{3}{c}{GMRES iterations} & \\multicolumn{3}{c}{$e_{H^1}$}\\\\\n$\\nu$ & $N=32$ & $64$ & $128$ & $N=32$ & $64$ & $128$\\\\\n\\midrule\n"
    for r in E7["nu"]:
        s += f"{r['nu']} & {r['its32']} & {r['its64']} & {r['its128']} & {sci(r['e32'])} & {sci(r['e64'])} & {sci(r['e128'])}\\\\\n"
    w("t_trac_nu", s + "\\bottomrule\n\\end{tabular}\n")
    s = "\\begin{tabular}{r " + "c" * 5 + " c}\n\\toprule\n$\\alpha$ & $N=32$ & $64$ & $128$ & $256$ & $512$ & rate\\\\\n\\midrule\n"
    for r in E7["enhanced1d"]:
        a = r["alpha"]; lab = "$-1/12$" if a < 0 else ("0 (plain)" if a == 0 else ("1/4" if a == .25 else "1/2"))
        s += lab + " & " + " & ".join(sci(v) for v in r["err"]) + f" & {rate(r['err'][-2], r['err'][-1], 256, 512)}\\\\\n"
    w("t_enh1d", s + "\\bottomrule\n\\end{tabular}\n")
    U = E7["sing_uniform"]; A = E7["sing_adaptive"]; st = max(1, len(A) // 8)
    sel = A[::st] + ([A[-1]] if (len(A) - 1) % st else [])
    s = "\\begin{tabular}{rrc rrcccr}\n\\toprule\n\\multicolumn{3}{c}{uniform} & \\multicolumn{6}{c}{automatic (Haar-detail indicator)}\\\\\n\\cmidrule(lr){1-3}\\cmidrule(lr){4-9}\nDOFs & $e_{H^1}$ & its & cycle & DOFs & $e_{H^1}$ & $h_{\\min}$ & $\\kappa(V)$ & its\\\\\n\\midrule\n"
    for i in range(max(len(U), len(sel))):
        u = U[i] if i < len(U) else None; a = sel[i] if i < len(sel) else None
        s += (f"{u['dofs']} & {sci(u['eH1'])} & {u['its']}" if u else "& &") + " & " + \
             (f"{a['cycle']} & {a['dofs']} & {sci(a['eH1'])} & {sci(a['hmin'])} & {a['condV']:.1f} & {a['its']}" if a else "& & & & &") + "\\\\\n"
    w("t_trac_sing", s + "\\bottomrule\n\\end{tabular}\n")
    print("E7 tables written")
