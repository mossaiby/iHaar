"""Reproduce every table and figure of the manuscript.

    python experiments/run_all.py [--only E1,E2,...]

Results -> results/*.json, figures -> figures/*.pdf.  CPU (NumPy) by default;
pass --gpu to run the phase-field timing study with CuPy.
"""
import json, os, sys, time, argparse
import numpy as np
import scipy.linalg as sla

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from ihaar.core import Grid1D, corrected_D2, Eig1D, TensorFDM, NeumannDCT
from ihaar.phasefield import SAVPhaseField
from ihaar.elasticity import (LAM_I as LAMB, WilliamsField, SmoothField, ElasticityTensor,
                              dorfler, bisect)
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = os.path.join(os.path.dirname(__file__), "..")
RES = os.path.join(ROOT, "results"); FIG = os.path.join(ROOT, "figures")
os.makedirs(RES, exist_ok=True); os.makedirs(FIG, exist_ok=True)
plt.rcParams.update({"font.size": 9, "figure.dpi": 150})


def save(name, obj):
    with open(os.path.join(RES, name + ".json"), "w") as fh:
        json.dump(obj, fh, indent=1)


def rates(e, n):
    e, n = np.asarray(e, float), np.asarray(n, float)
    return [None] + list(np.log(e[:-1] / e[1:]) / np.log(n[1:] / n[:-1]))


# ---------------------------------------------------------------------------
# E1: Poisson-type verification and solver cost
# ---------------------------------------------------------------------------
def E1():
    out = {}
    # (a) Dirichlet: -Lap u = f, u = exp(x) sin(pi y) + x^2 y   (not odd-compatible)
    ue = lambda x, y: np.exp(x) * np.sin(np.pi * y) + x * x * y
    lap = lambda x, y: (1 - np.pi ** 2) * np.exp(x) * np.sin(np.pi * y) + 2 * y
    rows = []
    for N in [8, 16, 32, 64, 128, 256, 512]:
        row = {"N": N}
        for label, mk in [("uniform", lambda N: np.linspace(0, 1, N + 1)),
                          ("graded", lambda N: 0.5 * (1 - np.cos(np.pi * np.linspace(0, 1, N + 1))))]:
            t = mk(N); g = Grid1D(t, "D"); X, Y = np.meshgrid(g.x, g.x, indexing="ij")
            bL, bR = ue(0 * g.x, g.x), ue(1 + 0 * g.x, g.x)
            bB, bT = ue(g.x, 0 * g.x), ue(g.x, 1 + 0 * g.x)
            Fm = lap(X, Y) - np.outer(g.e0, bL) - np.outer(g.e1, bR) - np.outer(bB, g.e0) - np.outer(bT, g.e1)
            e = Eig1D(g.D2); fd = TensorFDM([e, e])
            U = fd.solve_diag(Fm, fd.lam_sum)
            row[label] = float(np.abs(U - ue(X, Y)).max())
        rows.append(row)
    out["dirichlet"] = rows
    # (b) Neumann: (I - Lap) u = f with u = cos(pi x)cos(2 pi y) + 0.3 cos(3 pi x)
    ue = lambda x, y: np.cos(np.pi * x) * np.cos(2 * np.pi * y) + 0.3 * np.cos(3 * np.pi * x)
    fn = lambda x, y: (1 + 5 * np.pi ** 2) * np.cos(np.pi * x) * np.cos(2 * np.pi * y) + 0.3 * (1 + 9 * np.pi ** 2) * np.cos(3 * np.pi * x)
    rows = []
    for N in [8, 16, 32, 64, 128, 256, 512]:
        g = Grid1D.uniform(N, bc="N"); X, Y = np.meshgrid(g.x, g.x, indexing="ij")
        row = {"N": N}
        for order in (2, 4):
            fd = NeumannDCT(N, 2, g.h[0], order=order)
            U = fd.solve_diag(fn(X, Y), 1 - fd.lam_sum)
            row[f"order{order}"] = float(np.abs(U - ue(X, Y)).max())
        rows.append(row)
    out["neumann"] = rows
    # (c) Cost of the linear solve: dense flattened (classical 2D HWCM) vs
    #     Bartels-Stewart vs FDM-GEMM vs DCT  for -Lap u = f (Neumann+I shift)
    rows = []
    for N in [16, 32, 64, 128, 256, 512, 1024]:
        g = Grid1D.uniform(N, bc="N"); F = np.random.default_rng(0).standard_normal((N, N))
        row = {"N": N, "dofs": N * N}
        A1 = np.eye(N) - g.D2
        if N <= 64:
            K = np.kron(A1, np.eye(N)) - np.kron(np.eye(N), g.D2)
            t0 = time.perf_counter(); np.linalg.solve(K, F.ravel()); row["dense"] = time.perf_counter() - t0
        t0 = time.perf_counter(); sla.solve_sylvester(A1, -g.D2.T, F); row["bartels_stewart"] = time.perf_counter() - t0
        e = Eig1D(g.D2, symmetric=True); fd = TensorFDM([e, e])
        t0 = time.perf_counter(); fd.solve_diag(F, 1 - fd.lam_sum); row["fdm_gemm"] = time.perf_counter() - t0
        fdd = NeumannDCT(N, 2, g.h[0])
        t0 = time.perf_counter(); fdd.solve_diag(F, 1 - fdd.lam_sum); row["dct"] = time.perf_counter() - t0
        rows.append(row)
    out["cost"] = rows
    save("E1", out)
    print("E1 dirichlet", [(r["N"], f"{r['uniform']:.2e}", f"{r['graded']:.2e}") for r in out["dirichlet"]])
    print("E1 neumann", [(r["N"], f"{r['order2']:.2e}", f"{r['order4']:.2e}") for r in out["neumann"]])
    print("E1 cost", out["cost"])


# ---------------------------------------------------------------------------
# E2: elasticity
# ---------------------------------------------------------------------------
def E2():
    out = {}
    # (a) smooth manufactured, convergence and GMRES iterations
    rows = []
    for N in [8, 16, 32, 64, 128, 256]:
        f = SmoothField(); t = np.linspace(0, 1, N + 1)
        el = ElasticityTensor(t, t); t0 = time.perf_counter()
        U, V, its, _ = el.solve(f, body=f.body); tt = time.perf_counter() - t0
        _, ei = el.errors(U, V, f); e = el.errors_gauss(U, V, f)
        rows.append(dict(N=N, dofs=2 * N * N, eH1=float(e), einf=float(ei), its=its, time=tt))
    out["smooth"] = rows
    rows = []
    for nu in [0.3, 0.4, 0.45, 0.49, 0.499]:
        r = {"nu": nu}
        for N in [32, 64, 128]:
            f = SmoothField(nu=nu); t = np.linspace(0, 1, N + 1)
            el = ElasticityTensor(t, t, nu=nu); U, V, its, _ = el.solve(f, body=f.body)
            r[f"its{N}"] = its; r[f"e{N}"] = float(el.errors_gauss(U, V, f))
        rows.append(r)
    out["nu"] = rows
    # (b) corner singularity: uniform vs automatic refinement
    fld = WilliamsField()
    rows = []
    for N in [8, 16, 32, 64, 128, 256]:
        t = np.linspace(0, 1, N + 1); el = ElasticityTensor(t, t)
        t0 = time.perf_counter(); U, V, its, _ = el.solve(fld); tt = time.perf_counter() - t0
        _, ei = el.errors(U, V, fld); e = el.errors_gauss(U, V, fld)
        rows.append(dict(N=N, dofs=2 * N * N, eH1=float(e), einf=float(ei), its=its, time=tt))
    out["sing_uniform"] = rows
    rows = []; tx = ty = np.linspace(0, 1, 9); grids = {}
    for cyc in range(200):
        el = ElasticityTensor(tx, ty); t0 = time.perf_counter()
        U, V, its, _ = el.solve(fld); tt = time.perf_counter() - t0
        _, ei = el.errors(U, V, fld); e = el.errors_gauss(U, V, fld); ex, ey = el.indicators(U, V)
        dofs = 2 * el.shape[0] * el.shape[1]
        rows.append(dict(cycle=cyc, nx=el.shape[0], ny=el.shape[1], dofs=dofs, eH1=float(e), einf=float(ei),
                         eta=float(np.sqrt(ex.sum() + ey.sum())), its=its, hmin=float(min(np.diff(tx).min(), np.diff(ty).min())),
                         condV=float(el.condV), time=tt))
        if cyc in (6, 14):
            grids[cyc] = (tx.tolist(), ty.tolist())
        if dofs > 1.2e5:
            break
        mx, my = dorfler(ex, ey, 0.6); tx = bisect(tx, mx); ty = bisect(ty, my)
    grids["final"] = (tx.tolist(), ty.tolist())
    out["sing_adaptive"] = rows; out["grids"] = grids
    save("E2", out)
    print("E2 smooth", [(r["N"], f"{r['eH1']:.2e}", r["its"]) for r in out["smooth"]])
    print("E2 nu", out["nu"])
    print("E2 unif", [(r["dofs"], f"{r['eH1']:.2e}", r["its"]) for r in out["sing_uniform"]])
    print("E2 adapt", [(r["dofs"], f"{r['eH1']:.2e}", r["its"], f"{r['condV']:.1f}") for r in out["sing_adaptive"][::3]])

    fig, ax = plt.subplots(1, 3, figsize=(10, 3.1))
    su, sa = out["sing_uniform"], out["sing_adaptive"]
    ax[0].loglog([r["dofs"] for r in su], [r["eH1"] for r in su], "o-", label="uniform")
    ax[0].loglog([r["dofs"] for r in sa], [r["eH1"] for r in sa], ".-", label="adaptive (Haar details)")
    ax[0].loglog([r["dofs"] for r in sa], [r["eta"] * sa[-1]["eH1"] / sa[-1]["eta"] for r in sa], ":", label="indicator (scaled)")
    d = np.array([3e2, 1.2e5])
    ax[0].loglog(d, su[1]["eH1"] * 1.4 * (d / su[1]["dofs"]) ** -0.2722, "k--", lw=0.8, label=r"DOF$^{-\lambda/2}$")
    ax[0].loglog(d, sa[-1]["eH1"] * 0.6 * (d / sa[-1]["dofs"]) ** -1.0, "k-.", lw=0.8, label=r"DOF$^{-1}$")
    ax[0].set_xlabel("DOFs"); ax[0].set_ylabel(r"relative $H^1$ error"); ax[0].legend(fontsize=6)
    gx_, gy_ = grids[14]
    for xv in gx_: ax[1].axvline(xv, lw=0.3, color="k")
    for yv in gy_: ax[1].axhline(yv, lw=0.3, color="k")
    ax[1].set_aspect("equal"); ax[1].set_xlim(0, 1); ax[1].set_ylim(0, 1)
    ax[1].set_title(f"cycle 14: {len(gx_)-1} x {len(gy_)-1} cells"); ax[1].plot([1], [1], "r*", ms=8, clip_on=False)
    for lab, kn in (("x", np.array(grids["final"][0])), ("y", np.array(grids["final"][1]))):
        hh = np.diff(kn); dist = 1 - 0.5 * (kn[:-1] + kn[1:])
        ax[2].loglog(dist, hh, ".", ms=3, label=f"{lab}-cells (final grid)")
    kn = np.array(grids["final"][0]); hh = np.diff(kn); dist = 1 - 0.5 * (kn[:-1] + kn[1:])
    msk = (dist > 1e-5) & (dist < 0.3); pf = np.polyfit(np.log(dist[msk]), np.log(hh[msk]), 1)
    out["grading_slope"] = float(pf[0]); save("E2", out)
    dd = np.logspace(-6, -0.3, 20)
    ax[2].loglog(dd, 2.5 * np.exp(pf[1]) * dd ** pf[0], "k--", lw=0.8, label="fit: $h\\propto d^{%.2f}$" % pf[0])
    ax[2].loglog(dd, 0.6 * np.exp(pf[1]) * dd ** (1 - LAMB / 2), "k:", lw=0.8, label="$d^{1-\\lambda/2}$ (optimal)")
    ax[2].set_xlabel("distance of cell to singular edge"); ax[2].set_ylabel("cell size h"); ax[2].legend(fontsize=6)
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "elasticity_corner.pdf"))


# ---------------------------------------------------------------------------
# E3: Allen-Cahn shrinking circle
# ---------------------------------------------------------------------------
def E3():
    eps, R0, dt, T = 0.02, 0.3, 0.05, 40.0
    out = {"eps": eps, "R0": R0, "dt": dt, "runs": {}}
    for N, order in [(64, 2), (64, 4), (128, 4), (256, 4)]:
        s = SAVPhaseField(N, 2, eps=eps, dt=dt, model="AC", order=order, transform="dct")
        X, Y = np.meshgrid(s.h * (np.arange(N) + .5), s.h * (np.arange(N) + .5), indexing="ij")
        r = np.hypot(X - .5, Y - .5)
        s.initialize(np.tanh((R0 - r) / (np.sqrt(2) * eps)))
        ts, R2, E, Em = [0.0], [float(s.w * ((1 + s.u) / 2).sum() / np.pi)], [s.energy(s.u)], []
        nst = int(round(T / dt))
        for n in range(nst):
            s.step()
            if (n + 1) % 20 == 0:
                ts.append((n + 1) * dt); R2.append(float(s.w * ((1 + s.u) / 2).sum() / np.pi))
                E.append(s.energy(s.u, s.uhat))
            if n >= 1:
                Em.append(s.modified_energy())
        slope = np.polyfit(ts[len(ts) // 4:], R2[len(ts) // 4:], 1)[0]
        out["runs"][f"N{N}_o{order}"] = dict(t=ts, R2=R2, E=E, slope=float(slope),
                                             max_dEmod=float(np.diff(Em).max()), max_dE=float(np.diff(E).max()))
        print("E3", N, order, "slope", slope, "law", -2 * eps ** 2, "max dEmod", np.diff(Em).max())
    save("E3", out)
    fig, ax = plt.subplots(1, 2, figsize=(7, 2.8))
    tt = np.linspace(0, T, 50)
    ax[0].plot(tt, R0 ** 2 - 2 * eps ** 2 * tt, "k--", label=r"$R_0^2-2\varepsilon^2 t$")
    for k, v in out["runs"].items():
        ax[0].plot(v["t"], v["R2"], label=k.replace("_o", ", order "))
        ax[1].plot(v["t"], v["E"], label=k)
    ax[0].set_xlabel("t"); ax[0].set_ylabel(r"$R^2$"); ax[0].legend(fontsize=6)
    ax[1].set_xlabel("t"); ax[1].set_ylabel(r"$E_h$")
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "allen_cahn_circle.pdf"))


# ---------------------------------------------------------------------------
# E4: Cahn-Hilliard: spatial / temporal convergence, spinodal decomposition
# ---------------------------------------------------------------------------
def ch_smooth_ic(N):
    x = (np.arange(N) + .5) / N
    X, Y = np.meshgrid(x, x, indexing="ij")
    return 0.1 + 0.25 * np.cos(2 * np.pi * X) * np.cos(np.pi * Y) + 0.15 * np.cos(3 * np.pi * Y) * np.cos(np.pi * X)


def E4():
    out = {}
    eps, T, dt = 0.05, 0.004, 2e-6
    Ns = [18, 54, 162, 486]
    res = {}
    for order in (2, 4):
        sols = {}
        for N in Ns:
            s = SAVPhaseField(N, 2, eps, dt, "CH", order, transform="dct")
            s.initialize(ch_smooth_ic(N))
            for n in range(int(round(T / dt))): s.step()
            sols[N] = s.u.copy()
        ref = sols[Ns[-1]]
        errs = []
        for N in Ns[:-1]:
            stride = Ns[-1] // N
            sub = ref[stride // 2::stride, stride // 2::stride]
            errs.append(float(np.abs(sols[N] - sub).max()))
        res[f"order{order}"] = errs
        print("E4 spatial order", order, errs, rates(errs, Ns[:-1]))
    out["spatial"] = dict(N=Ns[:-1], **res, T=T, dt=dt, eps=eps)
    # temporal convergence
    N, T = 128, 0.004
    sref = SAVPhaseField(N, 2, eps, T / 6400, "CH", 4, transform="dct"); sref.initialize(ch_smooth_ic(N))
    for n in range(6400): sref.step()
    terr = []; dts = []
    for M in [25, 50, 100, 200, 400]:
        s = SAVPhaseField(N, 2, eps, T / M, "CH", 4, transform="dct"); s.initialize(ch_smooth_ic(N))
        for n in range(M): s.step()
        terr.append(float(np.abs(s.u - sref.u).max())); dts.append(T / M)
    out["temporal"] = dict(dt=dts, err=terr)
    print("E4 temporal", terr, rates(terr, 1 / np.array(dts)))
    # spinodal decomposition
    N, eps, dt, nst = 256, 0.01, 2e-6, 5000
    s = SAVPhaseField(N, 2, eps, dt, "CH", 4, transform="dct")
    rng = np.random.default_rng(7)
    s.initialize(0.1 + 0.05 * rng.uniform(-1, 1, (N, N)))
    m0 = s.mass(s.u); E = [s.energy(s.u)]; Em = []; Em2 = []; mdev = []; xi = []; ts = [0.0]; snaps = {}
    t0 = time.perf_counter()
    for n in range(nst):
        s.step()
        if n >= 1: Em.append(s.modified_energy())
        if (n + 1) % 25 == 0:
            E.append(s.energy(s.u, s.uhat)); ts.append((n + 1) * dt)
            mdev.append(abs(s.mass(s.u) - m0)); xi.append(s.r / np.sqrt(s.E1(s.u) + s.C))
        if (n + 1) in (1000, 5000): snaps[(n + 1) * dt] = s.u.copy()
    tt = time.perf_counter() - t0
    # continuation with a 10x larger step (SAV restart), coarsening stage
    t_now = nst * dt; dt2 = 2e-5; s2 = SAVPhaseField(N, 2, eps, dt2, "CH", 4, transform="dct"); s2.initialize(s.u)
    for n in range(4500):
        s2.step()
        if (n + 1) % 25 == 0:
            E.append(s2.energy(s2.u, s2.uhat)); ts.append(t_now + (n + 1) * dt2)
            mdev.append(abs(s2.mass(s2.u) - m0)); xi.append(s2.r / np.sqrt(s2.E1(s2.u) + s2.C))
        if n >= 1: Em2.append(s2.modified_energy())
    snaps[t_now + 4500 * dt2] = s2.u.copy()
    out["spinodal"] = dict(N=N, eps=eps, dt=dt, steps=nst, t=ts, E=E, max_mass_dev=float(max(mdev)),
                           max_dEmod=float(max(np.diff(Em).max(), np.diff(Em2).max())), max_dE=float(np.diff(E).max()),
                           xi_min=float(min(xi)), xi_max=float(max(xi)), time_per_step=tt / nst)
    print("E4 spinodal mass", max(mdev), "dEmod", max(np.diff(Em).max(), np.diff(Em2).max()), "dE", np.diff(E).max(), "xi", min(xi), max(xi), tt / nst)
    save("E4", out)
    fig, ax = plt.subplots(1, 4, figsize=(10, 2.5))
    for k, (tk, u) in enumerate(sorted(snaps.items())):
        ax[k].imshow(u.T, origin="lower", extent=[0, 1, 0, 1], cmap="RdBu_r", vmin=-1, vmax=1)
        ax[k].set_title(f"t = {tk:.4f}"); ax[k].set_xticks([]); ax[k].set_yticks([])
    ax[3].semilogx(ts[1:], E[1:]); ax[3].set_xlabel("t"); ax[3].set_ylabel(r"$E_h$")
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "cahn_hilliard_spinodal.pdf"))
    fig, ax = plt.subplots(1, 2, figsize=(6.5, 2.6))
    for o, mk in ((2, "o-"), (4, "s-")):
        ax[0].loglog(Ns[:-1], res[f"order{o}"], mk, label=f"order {o} operator")
    n_ = np.array(Ns[:-1], float)
    ax[0].loglog(n_, res["order2"][0] * (n_ / n_[0]) ** -2, "k--", lw=.7)
    ax[0].loglog(n_, res["order4"][0] * (n_ / n_[0]) ** -4, "k-.", lw=.7)
    ax[0].set_xlabel("N"); ax[0].set_ylabel(r"max error"); ax[0].legend(fontsize=7)
    ax[1].loglog(dts, terr, "o-"); ax[1].loglog(dts, terr[0] * (np.array(dts) / dts[0]) ** 2, "k--", lw=.7)
    ax[1].set_xlabel(r"$\Delta t$"); ax[1].set_ylabel("max error")
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "cahn_hilliard_convergence.pdf"))


# ---------------------------------------------------------------------------
# E5: 3D Cahn-Hilliard
# ---------------------------------------------------------------------------
def E5():
    N, eps, dt, nst = 96, 0.02, 5e-6, 1500
    s = SAVPhaseField(N, 3, eps, dt, "CH", 4, transform="dct")
    rng = np.random.default_rng(11)
    s.initialize(0.0 + 0.05 * rng.uniform(-1, 1, (N, N, N)))
    m0 = s.mass(s.u); E = [s.energy(s.u)]; Em = []
    t0 = time.perf_counter()
    for n in range(nst):
        s.step()
        if n >= 1: Em.append(s.modified_energy())
        if (n + 1) % 50 == 0: E.append(s.energy(s.u, s.uhat))
    tt = time.perf_counter() - t0
    out = dict(N=N, eps=eps, dt=dt, steps=nst, mass_dev=float(abs(s.mass(s.u) - m0)),
               max_dEmod=float(np.diff(Em).max()), max_dE=float(np.diff(E).max()), time_per_step=tt / nst, E=E)
    save("E5", out)
    print("E5", {k: v for k, v in out.items() if k != "E"})
    fig, ax = plt.subplots(1, 3, figsize=(7.5, 2.5))
    for k, idx in enumerate([N // 4, N // 2, 3 * N // 4]):
        ax[k].imshow(s.u[:, :, idx].T, origin="lower", cmap="RdBu_r", vmin=-1, vmax=1)
        ax[k].set_title(f"z = {(idx + .5) / N:.2f}"); ax[k].set_xticks([]); ax[k].set_yticks([])
    fig.tight_layout(); fig.savefig(os.path.join(FIG, "cahn_hilliard_3d.pdf"))


# ---------------------------------------------------------------------------
# E6: time per step (CPU here; --gpu for CuPy)
# ---------------------------------------------------------------------------
def E6(gpu=False):
    if gpu:
        import cupy as xp
        sync = lambda: xp.cuda.Stream.null.synchronize()
    else:
        xp = np; sync = lambda: None
    rows = []
    for dim, Ns in ((2, [128, 256, 512, 1024, 2048]), (3, [32, 64, 128])):
        for N in Ns:
            for tr in ("gemm", "dct"):
                if gpu is False and dim == 2 and N == 2048 and tr == "gemm":
                    continue
                for dtype in ((xp.float64, xp.float32) if gpu else (xp.float64,)):
                    s = SAVPhaseField(N, dim, 0.01, 1e-6, "CH", 4, xp=xp, dtype=dtype, transform=tr)
                    u0 = xp.asarray(0.1 + 0.01 * np.random.default_rng(0).standard_normal((N,) * dim), dtype=dtype)
                    s.initialize(u0); s.step(); s.step(); sync()
                    reps = 20 if N ** dim <= 2 ** 20 else 5
                    t0 = time.perf_counter()
                    for _ in range(reps): s.step()
                    sync(); tps = (time.perf_counter() - t0) / reps
                    rows.append(dict(dim=dim, N=N, dofs=N ** dim, transform=tr, dtype=str(np.dtype(dtype).name),
                                     ms_per_step=1e3 * tps, mdofs_per_s=N ** dim / tps / 1e6))
                    print("E6", rows[-1])
    save("E6_gpu" if gpu else "E6_cpu", rows)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="E1,E2,E3,E4,E5,E6")
    ap.add_argument("--gpu", action="store_true")
    a = ap.parse_args()
    for name in a.only.split(","):
        t0 = time.time()
        if name == "E6":
            E6(a.gpu)
        else:
            globals()[name]()
        print(f"[{name} done in {time.time() - t0:.1f}s]", flush=True)
