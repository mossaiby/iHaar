# ihaar — integrated-Haar wavelet collocation with fast tensor solvers

Code, tests and reproduction scripts for the manuscript in `paper/manuscript.tex`.

## Layout
```
ihaar/core.py        three-term identity (Theorem 1): D2 = A^{-1} L, D1, boundary vectors;
                     4th-order correction; fast diagonalization (GEMM) and DCT solvers;
                     spline reconstruction for Gauss-quadrature error norms
ihaar/phasefield.py  SAV-BDF1/BDF2 Allen–Cahn and Cahn–Hilliard (2D/3D, Neumann, uniform)
ihaar/elasticity.py  plane-strain collocation on graded tensor grids, Williams corner field,
                     FDM-block-preconditioned GMRES, Haar-detail indicator, Dörfler marking
tests/               unit/verification tests (identity vs classical HWCM matrices, symmetry,
                     mass, energy decay, exact-field checks, DCT == eigenbasis)
experiments/run_all.py     every table/figure  (E1 … E6)
experiments/make_tables.py LaTeX tables generated from results/*.json
paper/               manuscript (elsarticle), generated tables, internal referee report
```

## Reproduce (CPU)
```
pip install numpy scipy matplotlib
for t in tests/test_*.py; do python $t; done
python experiments/run_all.py            # ~5 min on one core
python experiments/make_tables.py
cd paper && latexmk -pdf manuscript.tex  # needs elsarticle.cls (TeX Live / CTAN)
```

## GPU (required before submission)
The phase-field and elasticity solvers take an array module `xp`:
```python
import cupy as cp
from ihaar import SAVPhaseField
s = SAVPhaseField(2048, 2, eps=0.01, dt=1e-5, model="CH", order=4, xp=cp, transform="gemm")
```
Run the timing study and regenerate Table 10:
```
pip install cupy-cuda12x
python experiments/run_all.py --only E6 --gpu   # writes results/E6_gpu.json
python experiments/make_tables.py
```
`transform="dct"` uses `cupyx.scipy.fft.dctn` if your CuPy provides it; otherwise use `"gemm"`.
**The GPU code path has been written for CuPy but could not be executed in the authoring
environment (no GPU). Run `tests/` with `xp=cupy` first and report any failures.**
